// src/components/LibroDestacado.jsx
const LibroDestacado = ({ titulo, descripcion, imagen, enlace }) => {
    return (
        <>
            <a href={enlace}>{titulo}</a>
            <p>{descripcion}</p>
            <img src={imagen} alt={titulo} />
            <br /><br /><br />
        </>
    );
};

export default LibroDestacado