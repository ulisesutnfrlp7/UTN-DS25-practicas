// src/components/Contenido.jsx
import LibroDestacado from './libro_destacado';

const Contenido = () => {
    return (
        <div id="contenido">
            <LibroDestacado
            titulo="¡NOVELA DESTACADA!"
            descripcion='"Los hermanos Karamazov" - Fiódor Dostoyevski'
            imagen="/IMÁGENES/hermanos.jpg"
            enlace="ej5_sección_novelas.html"
            />
            <LibroDestacado
                titulo="¡SCI-FI DESTACADO!"
                descripcion='"Neuromante" - William Gibson'
                imagen="/IMÁGENES/neuromante.jpg"
                enlace="ej5_sección_ciencia_ficción.html"
            />
            <LibroDestacado
                titulo="¡TERROR DESTACADO!"
                descripcion='"La llamada de Cthulhu" - H. P. Lovecraft'
                imagen="/IMÁGENES/lovecraft.jpg"
                enlace="ej5_sección_terror.html"
            />
            <LibroDestacado
                titulo="¡POLICIAL DESTACADO!"
                descripcion='"Perdida" (Gone Girl) - Gillian Flynn'
                imagen="/IMÁGENES/perdida.jpg"
                enlace="ej5_sección_policiales.html"
            />
        </div>
    );
};

export default Contenido;