// src/components/Menu.jsx
const Menu = () => {
    return (
    <div id="menu">
        <a href="ej5_sección_novelas.html">SECCIÓN NOVELAS</a>
        <a href="ej5_sección_ciencia_ficción.html">SECCIÓN CIENCIA FICCIÓN</a> <br /><br /><br />
        <a href="ej5_sección_terror.html">SECCIÓN TERROR</a>
        <a href="ej5_sección_policiales.html">SECCIÓN POLICIALES</a>
        <br /><br /><br />
        <a href="ej5_registro.html">REGISTRO</a>
        <a href="ej5_contacto.html">CONTACTO</a>
    </div>
    );
};

export default Menu;