// src/components/Header.jsx
const Header = () => {
    return (
    <div id="cabecera">
        <span>LIBRERÍA YENNY</span>
        <img src="/IMÁGENES/yenny-el-ateneo.jpg" alt="Librería Yenny" />
    </div>
);
};

export default Header;