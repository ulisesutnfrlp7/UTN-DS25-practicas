// src/components/Layout.jsx
import Header from './header';
import Menu from './menu';
import Contenido from './contenido';
import Footer from './footer';
import '../App.css'; //

const Layout = () => {
    return (
        <div id="contenedor">
            <Header />
            <Menu />
            <Contenido />
            <Footer />
        </div>
    );
};

export default Layout;