// src/components/Footer.jsx
const Footer = () => {
    return (
        <div id="pie">
            <p>
                © Librería Yenny. All rights reserved --- 
                <span id="tw"> TWITTER</span>: yenny_libreria_ok --- 
                <span id="ig"> INSTAGRAM</span>: yenny_libreria
            </p>
        </div>
    );
};

export default Footer;